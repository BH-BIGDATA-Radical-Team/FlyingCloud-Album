<template>
  <div class="about">
    <h1>This is also a TEST_FILE_PAGE : Album .</h1>
  </div>
</template>
