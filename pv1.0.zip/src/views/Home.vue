<template>
  <div class="home">
    <GUI/>
  </div>
</template>

<script>
// @ is an alias to /src
import GUI from '@/components/GUI.vue'

export default {
  name: 'Home',
  components: {
    GUI
  }
}
</script>
