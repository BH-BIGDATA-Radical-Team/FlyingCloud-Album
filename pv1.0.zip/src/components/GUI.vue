<template>
  <div id="GUI" class="GUI-main">
    <span>This is a TEST_FILE_PAGE : GUI ( it was above in THE_HOME_PAGE ) .
      <br />It means that your target item also is Home
    </span>
  </div>
</template>

<script>
export default {
  name: "GUI",
};
</script>
